export { RegisterScreen as default } from '@/features/auth';
