export * from './screens/SplashScreen';
